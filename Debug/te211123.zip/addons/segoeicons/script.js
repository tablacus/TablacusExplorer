if (window.Addon == 1) {
	const Addon_Id = "segoeicons";
	$.importScript("addons\\" + Addon_Id + "\\sync.js");
}
